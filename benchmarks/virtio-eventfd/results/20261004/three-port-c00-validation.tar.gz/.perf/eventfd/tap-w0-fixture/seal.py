import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

os.umask(0o077)
root = Path.cwd()
fixture = root / ".perf/eventfd/tap-w0-fixture"
run = fixture / "c00-01"
published = root / "benchmarks/virtio-eventfd/results/20261004"
result = json.loads((run / "result.json").read_text())
assert result["status"] == "passed" and not result["errors"] and not result["not_executed"]
assert result["graceful_shutdown_exit_code"] == 0
counts = {}
pids = set()
for mode in ("rpc", "h2g", "g2h", "wake"):
    sample = json.loads((run / f"{mode}.json").read_text())
    peer = json.loads((run / f"{mode}-peer.json").read_text())
    assert not sample["errors"] and sample["successful_requests"] > 0
    counts[mode] = sample["successful_requests"]
    pids.add(peer["pid"])
for name in ("namespace.json", "controller.json"):
    pids.add(json.loads((run / name).read_text())["pid"])
cleanup = json.loads((run / "teardown.json").read_text())
assert cleanup["supervisor_exit_code"] == 0
pids.update((cleanup["supervisor_pid"], cleanup["vmm_pid"]))
for row in json.loads((run / "isolation.json").read_text()):
    assert row["Uid"].split() == ["1000"] * 4 and row["Gid"].split() == ["1000"] * 4
    assert not row["Groups"] and row["CapEff"] == "0000000000000000"
    assert row["NoNewPrivs"] == "1" and row["Seccomp"] == "2"
    pids.update((row["pid"], row["tid"]))
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)
build = json.loads((fixture / "fixture-build-receipt.json").read_text())
assert hashlib.sha256((root / ".perf/eventfd/fixtures/legacy/flint").read_bytes()).hexdigest() == build["preserved_binary_sha256"]["untouched_L0"]
assert hashlib.sha256((root / ".perf/eventfd/q6/ReleaseSafe/flint").read_bytes()).hexdigest() == build["preserved_binary_sha256"]["current_correctness_Safe"]
selected = [path for path in run.rglob("*") if path.is_file() and not path.is_symlink()]
selected.extend(fixture / name for name in (
    "probe.py", "seal.py", "build.log", "hashes.txt", "zig-version.txt", "source-head.txt",
    "fixture-build-receipt.json", "verification.log", "c00-01-phase.log",
    "src/guest.c", "src/guest-init.sh", "src/collect.py",
))
archive_path = published / "three-port-c00-validation.tar.gz"
receipt_path = published / "three-port-c00-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
files = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        assert len(payload) <= 25 * 1024 * 1024
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        files.append({"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()})
    payload = json.dumps({"files": files, "scope": "only own new three-port C00 diagnostic; no images/ELFs or sibling runtime"}, indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(payload), 0o600, 0
    archive.addfile(info, io.BytesIO(payload))
with tarfile.open(archive_path, "r:gz") as archive:
    for record in files:
        assert hashlib.sha256(archive.extractfile(record["path"]).read()).hexdigest() == record["sha256"]
receipt = {
    "issue": 3, "date": "2026-10-05",
    "classification": "separate short three-port C00 fixture correctness; not untouched L0, frozen A/A or candidate performance",
    "source_head": "469424b78f8931a155aa784a1c900716851c4b84",
    "binary_sha256": build["preserved_binary_sha256"]["current_correctness_Safe"],
    "untouched_L0_sha256_preserved": build["preserved_binary_sha256"]["untouched_L0"],
    "initrd_sha256": build["sha256"]["initrd.cpio.gz"],
    "source_commit": build["source_commit"], "fixture_only_import": build["source_blobs"],
    "runtime_imported": False, "sibling_worktree_read": False,
    "passing_transaction_classes": 4, "successful_requests": counts,
    "bulk_h2g_MiB_verified": 8 * counts["h2g"], "bulk_g2h_MiB_verified": 8 * counts["g2h"],
    "direction": "host initiates TCP to guest listeners7000/7001/7002",
    "integrity": "numbered64-byte exact RPC echo;8MiB0x5a bulk bytes and count/error acknowledgement, not CRC",
    "agent_present": False, "heartbeat_ms": 0, "backend_periodic_timer": False,
    "quiescence": "one second before first client and between cases; wake collector additionally sleeps one second",
    "isolation": "new mount+network namespace; privateTAP h3w0tap0/MTU1500/offloads0; all observed VMM tasks UID/GID1000/groups empty/CapEff0/NNP1/Seccomp2",
    "host_network_changes": False, "uplink": None, "nat": None, "default_route": None,
    "cleanup": cleanup, "recorded_owned_PID_TID_numbers": len(pids),
    "all_recorded_owned_numbers_absent_at_seal": True,
    "helper_census_limit": "short sudo/inspection/bootstrap helpers waited; their creation PID census not complete",
    "accounting_limit": "collector aggregate host CPU is noise/control only; hardcoded legacy notification label ignored; scalar all-VMM-task deltas do not include full marginal softirq/scheduler attribution and raw per-window task counters were not persisted",
    "new_candidate_performance_samples": 0, "performance_merge_eligible": False,
    "new_short_windows_pooled_with_frozen_baselines": False, "product_demand_proven": False,
    "existing_noise_and_halt_save_blockers_changed": False,
    "archive": archive_path.name, "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "archive_bytes": archive_path.stat().st_size, "verified_files": len(files),
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"archive_sha256": receipt["archive_sha256"], "bytes": receipt["archive_bytes"],
                  "files": len(files), "recorded_owned_IDs_absent": len(pids),
                  "receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest()}))
