import argparse
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import struct
import subprocess
import sys
import time

sys.path.insert(0, str(Path.cwd() / "benchmarks/virtio-eventfd"))
import control
import probe_jail
import run as bench

os.umask(0o077)
signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(RuntimeError("bounded owned TAP phase interrupted")))
parser = argparse.ArgumentParser()
parser.add_argument("--controller", action="store_true")
args = parser.parse_args()
fixture = bench.artifact_path(".perf/eventfd/tap-w0-fixture")
out = fixture / "c00-01"


def save(name, data):
    bench.save_json(out / name, data)


def controller():
    if os.geteuid() == 0:
        raise RuntimeError("traffic controller must be nonroot")
    os.sched_setaffinity(0, {1})
    result = {
        "status": "failed", "errors": [], "mode": "C00",
        "classification": "separate three-port fixture correctness diagnostic; not untouched L0, A/A or candidate performance",
        "performance_merge_eligible": False, "agent_present": False, "heartbeat_ms": 0,
        "collector_host_cpu_fields": "aggregate noise/control only, not owned backend attribution",
        "collector_notification_label": "historical hardcoded legacy label ignored; actual C00 uses blocking readiness owners and direct IRQ",
        "not_executed": ["rpc", "h2g", "g2h", "wake"], "peers": [],
    }
    vm = control.support.OwnedVm(out / "j")
    peer = None
    try:
        receipt = json.loads((fixture / "fixture-build-receipt.json").read_text())
        for name in ("bzImage", "initrd.cpio.gz"):
            if bench.digest(fixture / name) != receipt["sha256"][name]:
                raise ValueError("fixture pin changed")
        binary = bench.artifact_path(".perf/eventfd/q6/ReleaseSafe/flint")
        if bench.digest(binary) != receipt["preserved_binary_sha256"]["current_correctness_Safe"]:
            raise ValueError("frozen current correctness binary changed")
        vm.path.mkdir(mode=0o700)
        vm.path_created = True
        for name in ("bzImage", "initrd.cpio.gz"):
            shutil.copyfile(fixture / name, vm.path / name)
        argv = [
            "sudo", "-n", "taskset", "-c", "8", str(binary),
            "--jail", str(vm.path), "--jail-uid", str(os.getuid()), "--jail-gid", str(os.getgid()),
            "--virtio-mode", "C00", "--api-sock", "/api.sock", "--tap", "h3w0tap0",
        ]
        save("command.json", {"argv": argv, "cwd": str(bench.ROOT)})
        vm.stdout = (out / "serial.txt").open("wb")
        vm.stderr = (out / "vmm.stderr").open("wb")
        vm.process = subprocess.Popen(argv, cwd=bench.ROOT, stdout=vm.stdout, stderr=vm.stderr)
        deadline = time.monotonic() + 10
        while not (vm.path / "api.sock").exists():
            if vm.process.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError("enforced API bootstrap failed")
            time.sleep(.02)
        vm.pid = vm.find_vm_pid()
        vm.pid_start_ticks = control.support.start_ticks(vm.pid)
        save("controller.json", {"pid": os.getpid(), "start_ticks": control.support.start_ticks(os.getpid())})
        vm.api("PUT", "/machine-config", {"mem_size_mib": 512, "vcpu_count": 1})
        vm.api("PUT", "/boot-source", {
            "kernel_image_path": "/bzImage", "initrd_path": "/initrd.cpio.gz",
            "boot_args": "console=ttyS0 reboot=k panic=1 pci=off",
        })
        vm.api("PUT", "/network-interfaces/eth0", {"iface_id": "eth0", "host_dev_name": "h3w0tap0"})
        vm.api("PUT", "/actions", {"action_type": "InstanceStart"})
        deadline = time.monotonic() + 20
        markers = (b"PERF_TAP_READY", b"PERF_LISTEN 7000", b"PERF_LISTEN 7001", b"PERF_LISTEN 7002")
        while not all(marker in (out / "serial.txt").read_bytes() for marker in markers):
            if vm.process.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError("three guest TCP listeners not ready")
            time.sleep(.02)
        inspected = subprocess.run(
            ["sudo", "-n", "python3", "-c", probe_jail.INSPECT, str(vm.process.pid)],
            capture_output=True, check=True, timeout=5,
        )
        roster = json.loads(inspected.stdout)
        save("isolation.json", roster)
        if not probe_jail.enforced_roster(roster, os.getuid(), os.getgid()):
            raise RuntimeError("enforced nonroot jail contract failed")
        save("manifest.json", {
            "binary_sha256": bench.digest(binary), "initrd_sha256": bench.digest(fixture / "initrd.cpio.gz"),
            "kernel_sha256": bench.digest(fixture / "bzImage"),
            "harness_sha256": bench.digest(Path(__file__)), "collector_sha256": bench.digest(fixture / "src/collect.py"),
            "mode": "C00", "cpus": [8], "client_cpus": [1], "ram_mib": 512, "vcpus": 1,
            "namespace": os.readlink("/proc/self/ns/net"), "tap": "h3w0tap0", "mtu": 1500,
            "offloads": 0, "uplink": None, "nat": None, "default_route": None,
            "direction": "host-initiated TCP to guest listeners", "vm_pid": vm.pid,
            "vm_start_ticks": vm.pid_start_ticks, "heartbeat_ms": 0, "guest_agent_present": False,
        })
        time.sleep(1)
        for mode in ("rpc", "h2g", "g2h", "wake"):
            before = bench.thread_roster(vm.pid)
            argv = [
                sys.executable, str(fixture / "src/collect.py"), "--mode", mode,
                "--warmup-seconds", "0", "--seconds", "1", "--timeout-seconds", "1",
                "--output", str(out / f"{mode}.json"),
            ]
            with (out / f"{mode}.stdout").open("wb") as stdout, (out / f"{mode}.stderr").open("wb") as stderr:
                peer = subprocess.Popen(argv, cwd=bench.ROOT, stdout=stdout, stderr=stderr)
                record = {"mode": mode, "argv": argv, "pid": peer.pid,
                          "start_ticks": control.support.start_ticks(peer.pid)}
                save(f"{mode}-peer.json", record)
                record["exit_code"] = peer.wait(timeout=8)
                peer = None
            sample = json.loads((out / f"{mode}.json").read_text())
            result["not_executed"].remove(mode)
            record["all_vm_task_cpu_seconds"] = bench.cpu_delta(before, bench.thread_roster(vm.pid))
            record["successful_requests"] = sample["successful_requests"]
            result["peers"].append(record)
            if record["exit_code"] != 0 or sample["errors"] or sample["successful_requests"] == 0:
                raise RuntimeError(f"{mode} real byte/sequence/ACK transaction failed")
            time.sleep(1)
        vm.api("PUT", "/actions", {"action_type": "SendCtrlAltDel"})
        result["graceful_shutdown_exit_code"] = vm.process.wait(timeout=15)
        if result["graceful_shutdown_exit_code"] != 0:
            raise RuntimeError("API shutdown did not join owners cleanly")
        result["status"] = "passed"
    except (OSError, ValueError, RuntimeError, EOFError, subprocess.SubprocessError) as error:
        result["errors"].append(f"{type(error).__name__}: {error}")
    finally:
        if peer is not None and peer.poll() is None:
            peer.terminate()
            try:
                peer.wait(timeout=3)
            except subprocess.TimeoutExpired:
                peer.kill()
                peer.wait(timeout=3)
        try:
            vm.close()
            if vm.path_created:
                if (vm.path / "exit.json").exists():
                    shutil.copyfile(vm.path / "exit.json", out / "teardown.json")
                subprocess.run(["sudo", "-n", "rm", "-rf", "--", str(vm.path)], check=True, timeout=10)
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            result["status"] = "failed"
            result["errors"].append(f"owned cleanup: {error}")
        save("result.json", result)
    print(json.dumps(result))
    return 0 if result["status"] == "passed" else 1


def namespace():
    if os.geteuid() != 0:
        raise RuntimeError("root bootstrap required only inside new namespace")
    for kind in ("net", "mnt"):
        if Path(f"/proc/self/ns/{kind}").stat().st_ino == Path(f"/proc/1/ns/{kind}").stat().st_ino:
            raise RuntimeError("refusing setup in host namespace")
    uid, gid = int(os.environ["SUDO_UID"]), int(os.environ["SUDO_GID"])
    if uid <= 0 or gid <= 0:
        raise RuntimeError("nonroot invoking identity required")
    out.mkdir(mode=0o700)
    os.chown(out, uid, gid)
    save("namespace.json", {"pid": os.getpid(), "start_ticks": control.support.start_ticks(os.getpid()),
                            "net": os.readlink("/proc/self/ns/net"), "mount": os.readlink("/proc/self/ns/mnt")})
    os.chown(out / "namespace.json", uid, gid)
    fd = os.open("/dev/net/tun", os.O_RDWR | os.O_CLOEXEC)
    try:
        fcntl.ioctl(fd, 0x400454CA, struct.pack("16sH22x", b"h3w0tap0", 0x0002 | 0x1000 | 0x4000))
        fcntl.ioctl(fd, 0x400454CC, uid)
        fcntl.ioctl(fd, 0x400454CB, 1)
        fcntl.ioctl(fd, 0x400454D0, 0)
    finally:
        os.close(fd)
    for argv in (["link", "set", "lo", "up"],
                 ["addr", "add", "192.0.2.1/30", "dev", "h3w0tap0"],
                 ["link", "set", "h3w0tap0", "mtu", "1500", "up"]):
        subprocess.run(["/usr/bin/busybox", "ip", *argv], check=True, timeout=5)

    def demote():
        os.setgroups([])
        os.setgid(gid)
        os.setuid(uid)

    worker = subprocess.Popen([sys.executable, str(Path(__file__)), "--controller"],
                              cwd=bench.ROOT, preexec_fn=demote)
    try:
        return worker.wait(timeout=110)
    finally:
        if worker.poll() is None:
            worker.terminate()
            worker.wait(timeout=20)


raise SystemExit(controller() if args.controller else namespace())
