import base64
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

os.umask(0o077)
root = Path.cwd()
private = root / ".perf/eventfd/q6"
out = root / "benchmarks/virtio-eventfd/results/20261004"
phases = [
    private / ("mixed-n4-C00-retry" if mode == "C00" and count == 4 else f"mixed-n{count}-{mode}")
    for mode in ("C00", "C10", "C01", "C11") for count in (4, 8)
]
pilot = private / "mixed-n4-C00"
assert json.loads((pilot / "result.json").read_text())["status"] == "failed"
pids, selected, cells, cleanup = set(), [], [], []
for phase in phases:
    result = json.loads((phase / "result.json").read_text())
    assert result["status"] == "passed" and not result["errors"]
    assert result["all_sandboxes_outstanding_at_release"] == result["count"]
    assert result["controller_exit_codes"] == [0] * result["count"]
    assert result["binary_sha256"] == "8f1ca382cc9678804cae31cecdfd4fcf7183e68986dd9249680edaae07bd8f6e"
    for sandbox in result["sandboxes"]:
        assert sandbox["status"] == "passed" and not sandbox["errors"]
        assert len(sandbox["vsock"]) == 128 and len(sandbox["tap"]) == 128
        assert sandbox["loaded_exec"] == "MIXED-EXEC"
        assert base64.b64decode(sandbox["loaded_interactive"]["stdout"], validate=True) == b"MIXED-PTY"
        assert sandbox["shutdown_exit_code"] == 0 and sandbox["paused_all_task_cpu_seconds"] == 0
    cells.append({"mode": result["mode"], "count": result["count"],
                  "path": str(phase.relative_to(root)), "status": result["status"],
                  "binary_sha256": result["binary_sha256"], "runner_sha256": result["runner_sha256"]})
for phase in [pilot] + phases:
    for path in phase.rglob("*"):
        if path.is_file() and not path.is_symlink() and (
                path.suffix in (".json", ".log", ".txt") or path.name == "vmm.stderr"):
            selected.append(path)
    selected.append(phase.with_suffix(".log"))
    for path in phase.rglob("isolation.json"):
        for row in json.loads(path.read_text()):
            assert row["Uid"].split() == ["1000"] * 4 and row["Gid"].split() == ["1000"] * 4
            assert not row["Groups"] and row["Seccomp"] == "2" and row["NoNewPrivs"] == "1"
            assert row["CapEff"] == "0000000000000000"
            pids.update((row["pid"], row["tid"]))
    for name in ("supervisor.json", "namespace-supervisor.json", "worker.json"):
        for path in phase.rglob(name):
            record = json.loads(path.read_text())
            pids.add(record["pid"])
    for path in phase.rglob("teardown.json"):
        record = json.loads(path.read_text())
        if phase != pilot:
            assert record["supervisor_exit_code"] == 0
        pids.update((record["supervisor_pid"], record["vmm_pid"]))
        cleanup.append({"path": str(path.relative_to(root)), **record})
assert len(cleanup) == 52
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)
test_log = private / "collector-gate-tests.log"
assert "Ran 20 tests" in test_log.read_text() and "\nOK\n" in test_log.read_text()
selected.extend((test_log, Path(__file__), root / "benchmarks/virtio-eventfd/mixed_scale.py",
                 root / "benchmarks/virtio-eventfd/test_run.py",
                 root / "benchmarks/virtio-eventfd/performance.py"))
archive_path = out / "mixed-scale-validation.tar.gz"
receipt_path = out / "mixed-scale-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
files = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        assert len(payload) <= 25 * 1024 * 1024
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        files.append({"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()})
    payload = json.dumps({"files": files, "scope": "owned mixed-scale current results plus preserved failed pilot; no images or raw traces"}, indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(payload), 0o600, 0
    archive.addfile(info, io.BytesIO(payload))
with tarfile.open(archive_path, "r:gz") as archive:
    for record in files:
        assert hashlib.sha256(archive.extractfile(record["path"]).read()).hexdigest() == record["sha256"]
receipt = {
    "issue": 3, "date": "2026-10-05", "classification": "real enforced mixed-device correctness; not candidate performance or true idle",
    "cells": cells, "passing_cells": 8, "passing_sandboxes": 48,
    "per_sandbox_messages_each_transport": 128, "message_bytes": 65536,
    "transport_integrity": "all numbered payloads and FNV checks verified; 12288 checked messages across48 sandboxes",
    "mandatory_checks": ["common actual outstanding block/TAP/vsock barrier", "loaded exec and PTY",
                         "disk producer completion and guest/host whole-disk SHA256", "acknowledged zero-CPU pause",
                         "timer-free native TAP/vsock wake after resume", "graceful owner join"],
    "guest_agent_poll_ms": 50, "backend_heartbeat_ms": 0,
    "preserved_failed_pilot": "4 sandbox C00, three16-message backlogs drained while sequentially booting peers; rejected by real writer-liveness assertion, not passing; retry128-message backlog retains assertion",
    "cleanup_receipts": cleanup, "recorded_owned_PID_TID_numbers": len(pids),
    "all_recorded_owned_numbers_absent_at_seal": True,
    "controller_census_limit": "original failed pilot had no namespace-supervisor PID census; wrappers were waited; orchestrator launch PID was not recorded",
    "noise_gates": "unchanged; fresh13/16-class C00 noise failure still prevents candidate performance",
    "performance_adoption_eligible": False, "default_changed": False,
    "archive": archive_path.name, "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "archive_bytes": archive_path.stat().st_size, "verified_files": len(files),
    "collector_gate_tests": 20,
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"archive_sha256": receipt["archive_sha256"], "bytes": receipt["archive_bytes"],
                  "files": len(files), "recorded_owned_IDs_absent": len(pids),
                  "receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest()}))
