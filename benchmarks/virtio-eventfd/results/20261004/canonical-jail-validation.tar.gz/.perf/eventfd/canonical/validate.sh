#!/usr/bin/env bash
set -euo pipefail
umask 077
cd /d/hearth/.perf/worktrees/virtio-eventfd
SCOPE=$1
OPT=$2
ROOT=$PWD
OUT="$ROOT/.perf/eventfd/canonical/rows/$SCOPE-$OPT"
test ! -e "$OUT"
mkdir -p "$OUT" "$OUT/scratch"
export PATH=/home/g/.local/bin:/usr/bin:$PATH
export TMPDIR="$OUT/scratch"
export ZIG_GLOBAL_CACHE_DIR="$ROOT/.perf/eventfd/cache/global"
export PYTHONDONTWRITEBYTECODE=1
export PERF_BUILDID_DIR="$OUT/perf-buildid"
export DEBUGINFOD_URLS=
export FLINT_JAIL_TEST_KERNEL="$ROOT/.perf/eventfd/fixtures/bzImage"
export FLINT_JAIL_TEST_REVISION=85e6f3b587f2820c11b8568fc2bd4f1332814bb1
SOURCE="$ROOT/vmm"
STEPS=(test eventfd-test integration-test)
OPTIONS=(-Dintegration-kernel="$FLINT_JAIL_TEST_KERNEL")
if [[ "$SCOPE" == bare ]]; then
    SOURCE="$ROOT/.perf/eventfd/canonical/vmm"
    STEPS=(test)
    OPTIONS=()
    export FLINT_JAIL_TEST_REVISION=7dfee42ed68fe1703744d6318f4be632113034b0
fi
{
    date --iso-8601=seconds
    printf 'scope=%s optimize=%s source=%s revision=%s\n' \
        "$SCOPE" "$OPT" "$SOURCE" "$FLINT_JAIL_TEST_REVISION"
    zig version
    sha256sum "$ROOT/tools/perf/test_jail_baseline.py" "$FLINT_JAIL_TEST_KERNEL"
    git hash-object "$SOURCE/src/jail.zig" "$SOURCE/src/seccomp.zig" "$SOURCE/src/tests.zig"
    stat -c '%a %u %g %n' /dev/kvm
    cd "$SOURCE"
    export ZIG_LOCAL_CACHE_DIR="$ROOT/.perf/eventfd/cache/local-$SCOPE"
    zig build install "${STEPS[@]}" -Dtarget=x86_64-linux-musl -Doptimize="$OPT" \
        "${OPTIONS[@]}" --summary all
    cp zig-out/bin/flint "$OUT/flint"
    sha256sum "$OUT/flint"
    readelf -l "$OUT/flint" | grep -E 'Type|INTERP|LOAD|Requesting' || true
    cd "$ROOT"
    export FLINT_JAIL_TEST_BINARY="$OUT/flint"
    python3 -m unittest discover -s tools/perf -p test_jail_baseline.py -v
    stat -c '%a %u %g %n' /dev/kvm
    date --iso-8601=seconds
} >"$OUT/validation.log" 2>&1
printf 'Completed %s %s: %s\n' "$SCOPE" "$OPT" "$OUT/validation.log"
