import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

os.umask(0o077)
root = Path.cwd()
private = root / ".perf/eventfd/canonical"
published = root / "benchmarks/virtio-eventfd/results/20261004"
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
rows = {}
selected = [private / "validate.sh", private / "seal.py",
            private / "collector-tests.log",
            private / "runtime-files/experiment-extensions.diff",
            root / "tools/perf/test_jail_baseline.py"]
collector = (private / "collector-tests.log").read_text()
assert "Ran 20 tests" in collector and "\nOK\n" in collector
for scope in ("bare", "current"):
    for opt in ("Debug", "ReleaseSafe"):
        directory = private / f"rows/{scope}-{opt}"
        text = (directory / "validation.log").read_text()
        count = 32 if scope == "bare" else 63
        assert f"{count}/{count} tests passed" in text
        assert "Ran 3 tests" in text and "\nOK\n" in text
        assert text.count("660 0 36 /dev/kvm") == 2
        rows[f"{scope}-{opt}"] = {
            "zig_tests_passed": count, "actual_common_tests_passed": 3,
            "elf_sha256": digest(directory / "flint"),
            "target": "x86_64-linux-musl",
            "compiler_selection": "existing default; no native override",
            "source": "7dfee42" if scope == "bare" else "85e6f3b",
        }
        selected.append(directory / "validation.log")
runs = sorted((root / ".perf/jail-baseline").iterdir())
assert len(runs) == 12
pids = set()
tasks = 0
for directory in runs:
    launch = json.loads((directory / "launch.json").read_text())
    assert "--cmdline" not in launch["argv"]
    pids.add(launch["supervisor_pid"])
    cleanup = json.loads((directory / "cleanup.json").read_text())
    assert not cleanup["live_pid_paths"]
    pids.update(map(int, cleanup["recorded_pids"]))
    roster = json.loads((directory / "owned-roster.json").read_text())
    for tid, text in roster.items():
        fields = dict(line.split(":", 1) for line in text.splitlines() if ":" in line)
        assert fields["Uid"].split() == ["1000"] * 4
        assert fields["Gid"].split() == ["1000"] * 4
        assert not fields["Groups"].strip()
        assert fields["CapEff"].strip() == "0000000000000000"
        assert fields["NoNewPrivs"].strip() == "1"
        assert fields["Seccomp"].strip() == "2"
        assert fields["Seccomp_filters"].strip() == "1"
        pids.add(int(tid))
        tasks += 1
    selected.extend(path for path in directory.iterdir()
                    if path.is_file() and path.suffix in (".json", ".log"))
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)
preserved = {
    "untouched_L0": ("fixtures/legacy/flint", "bd10cfef94ef4cf2402e485913b3f4a9ffb93f9cf80d25d0310d093b55111d23"),
    "old_current_Safe": ("q6/ReleaseSafe/flint", "8f1ca382cc9678804cae31cecdfd4fcf7183e68986dd9249680edaae07bd8f6e"),
    "old_current_Debug": ("q6/Debug/flint", "ccd6f4fb476925efe297aac9c21f5f30d8a0172e91a0bd35a9249a9d96955c34"),
}
for relative, expected in preserved.values():
    assert digest(root / ".perf/eventfd" / relative) == expected
archive_path = published / "canonical-jail-validation.tar.gz"
receipt_path = published / "canonical-jail-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
records = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        assert len(payload) < 25 * 1024 * 1024
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        records.append({"path": name, "bytes": len(payload),
                        "sha256": hashlib.sha256(payload).hexdigest()})
    payload = json.dumps({"files": records}, indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(payload), 0o600, 0
    archive.addfile(info, io.BytesIO(payload))
with tarfile.open(archive_path, "r:gz") as archive:
    for row in records:
        assert hashlib.sha256(archive.extractfile(row["path"]).read()).hexdigest() == row["sha256"]
receipt = {
    "issue": 3, "date": "2026-10-05", "classification": "canonical prerequisite correctness only",
    "canonical_source": "7dfee42ed68fe1703744d6318f4be632113034b0",
    "experiment_cherry_pick": "85e6f3b587f2820c11b8568fc2bd4f1332814bb1",
    "canonical_jail_blob": "fcda3fbf0fbdb20285a6ebed9930456751b38ae7",
    "canonical_seccomp_blob": "10d0c7bf65931d533d88caaaf5ac592a39f79333",
    "experimental_seccomp_blob": "4f52431203a451354413fd742794861663c4d007",
    "experimental_additions": ["confined eventfd2", "Unix SO_ERROR query"],
    "rows": rows, "zig_tests_passed": 190, "actual_enforced_common_tests_passed": 12,
    "collector_guard_tests_passed": 20,
    "skips": 0, "fixture_only_change": "remove unsupported --cmdline token; supported positional string retained",
    "fixture_sha256": digest(root / "tools/perf/test_jail_baseline.py"),
    "compiler_sha256": digest(Path("/home/g/.local/bin/zig")),
    "observed_isolated_tasks": tasks, "recorded_owned_PID_TID_numbers": len(pids),
    "all_recorded_owned_numbers_absent_at_seal": True,
    "host_kvm_metadata_unchanged": "root:kvm0660",
    "helper_census_limit": "short compiler/inspection/packing helpers not completely creation-censused; waited bounded helpers and recorded VMM IDs only",
    "old_elf_pins_preserved": {name: value[1] for name, value in preserved.items()},
    "new_candidate_performance_samples": 0, "performance_merge_eligible": False,
    "mandatory_noise_lifecycle_irq_accounting_blockers_changed": False,
    "runtime_optimization_imported": False, "sibling_worktree_read": False,
    "archive": archive_path.name, "archive_sha256": digest(archive_path),
    "archive_bytes": archive_path.stat().st_size, "verified_files": len(records),
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"archive_sha256": receipt["archive_sha256"],
                  "archive_bytes": receipt["archive_bytes"], "files": len(records),
                  "observed_tasks": tasks, "owned_numbers_absent": len(pids),
                  "receipt_sha256": digest(receipt_path)}))
