import hashlib
import json
import os
from pathlib import Path

os.umask(0o077)
root = Path.cwd()
folders = [
    "local-current/o/f2be8032c6f00cfb6368198b045838bb",
    "local-current/o/a68ff18fdf724ffd0fb4ce037cd77c3b",
    "local-current/o/6511989f4a6d73a22577cdbd5382548f",
    "local-bare/o/cbe530a3bb83e4e8c56e61eaee0beaaf",
    "local-current/o/7a6d35d5098fe5941990231cfbedacb6",
    "local-current/o/d9b4adf5d2033e00315b6f95442ad9ec",
    "local-current/o/239085af8fc26f10ed1a9dfbfa555ec2",
    "local-current/o/6dafb36784604721ff7fe18a134ed6d5",
]
records = []
for folder in folders:
    directory = root / ".perf/eventfd/cache" / folder
    name = "flint" if folder.endswith("6dafb36784604721ff7fe18a134ed6d5") else "test"
    executable = directory / name
    derived = directory / f"{name}_zcu.o"
    assert executable.is_file() and not executable.is_symlink()
    assert derived.is_file() and not derived.is_symlink()
    assert derived.stat().st_uid == os.getuid()
    assert executable.read_bytes()[:4] == b"\x7fELF"
    records.append({
        "removed_path": str(derived.relative_to(root)),
        "bytes": derived.stat().st_size,
        "allocated_bytes": derived.stat().st_blocks * 512,
        "removed_sha256": hashlib.sha256(derived.read_bytes()).hexdigest(),
        "retained_executable": str(executable.relative_to(root)),
        "retained_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
    })
for record in records:
    (root / record["removed_path"]).unlink()
    assert hashlib.sha256((root / record["retained_executable"]).read_bytes()).hexdigest() == record["retained_sha256"]
receipt = {
    "scope": "eight explicitly named own derived Safe compiler intermediates only",
    "raw_logs_source_abi_dependencies_and_all_executed_elfs_preserved": True,
    "frozen_runtime_images_or_performance_inputs_removed": False,
    "global_or_unowned_cache_modified": False,
    "records": records,
    "removed_allocated_bytes": sum(row["allocated_bytes"] for row in records),
    "free_bytes_after": os.statvfs(root).f_bavail * os.statvfs(root).f_frsize,
    "capacity_change_attribution": "only named allocated bytes claimed, no attribution of other filesystem changes",
}
(root / ".perf/eventfd/pause-stage/owned-derived-cleanup.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({key: receipt[key] for key in ("removed_allocated_bytes", "free_bytes_after")}))
