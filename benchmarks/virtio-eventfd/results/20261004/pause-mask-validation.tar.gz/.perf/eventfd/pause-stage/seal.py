import hashlib
import io
import json
import os
from pathlib import Path
import re
import statistics
import tarfile

os.umask(0o077)
root = Path.cwd()
private = root / ".perf/eventfd/pause-stage"
public = root / "benchmarks/virtio-eventfd/results/20261004"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
selected = [private / "seal.py", private / "cleanup-derived.py",
            private / "owned-derived-cleanup.json", private / "owned-derived-cleanup.log"]
rows = {}
pids = set()
elfs = []
for opt in ("Debug", "ReleaseSafe"):
    directory = private / opt
    text = (directory / "test.log").read_text()
    assert "run test 20 pass (20 total)" in text and "run test 7 pass (7 total)" in text
    assert "production_test_timing_symbols_absent" in text
    assert "Ran 3 tests" in text and "\nOK\n" in text
    if opt == "ReleaseSafe":
        units = (directory / "unit-rerun.log").read_text()
        assert "All 39 tests passed" in units
    else:
        assert "run test 39 pass (39 total)" in text
    pending = []
    samples = {}
    for line in text.splitlines():
        match = re.search(r"pause_ioctl operation=(.+?) request=0x([0-9a-f]+) identity=0x([0-9a-f]+) ns=(\d+)", line)
        if match:
            pending.append({"operation": match[1], "request": int(match[2], 16),
                            "identity": int(match[3], 16), "ns": int(match[4])})
        match = re.search(r"pause_diagnostic mode=(C\d\d) sample=(\d+) queues=9 gsis=3 owner_ns=(\d+) deassign_ns=(\d+) calls=(\d+)", line)
        if match:
            assert len(pending) == int(match[5])
            assert sum(event["ns"] for event in pending) == int(match[4])
            samples.setdefault(match[1], []).append({
                "sample": int(match[2]), "owner_ns": int(match[3]),
                "deassign_ns": int(match[4]), "calls": int(match[5]), "events": pending,
            })
            pending = []
    assert not pending
    summary = {}
    for mode in ("C00", "C10", "C01", "C11"):
        cells = samples[mode]
        assert len(cells) == 3
        wall = statistics.mean(row["owner_ns"] for row in cells)
        kernel = statistics.mean(row["deassign_ns"] for row in cells)
        summary[mode] = {"mean_owner_ms": wall / 1e6, "mean_deassign_ms": kernel / 1e6,
                         "ioctl_wall_fraction": kernel / wall, "samples": cells}
    children = re.findall(r"enforced_case child_pid=(\d+) waited=(\d+) status=(\d+)", text)
    assert len(children) == 19
    for pid, waited, status in children:
        assert pid == waited and status == "0"
        pids.add(int(pid))
    halted = re.findall(r"post_iret halted tid=(\d+) irqs=([12]) ioapic=(true|false) irqfd=(true|false) reset=(true|false)", text)
    assert len(halted) == 16
    pids.update(int(row[0]) for row in halted)
    rows[opt] = {
        "actual_tests": {"units": 39, "dedicated": 20, "existing_integration": 7, "enforced_common": 3},
        "post_iret_halt_cases": 16, "dormant_pause_samples": 12,
        "elf_sha256": sha(directory / "flint"), "pause": summary,
        "target": "x86_64-linux-musl", "compiler_selection": "existing default, no native override",
        "test_timing_symbols_absent_from_production": True,
        "safe_units_execution": "explicit retained artifact, not cached runner count" if opt == "ReleaseSafe" else "fresh build-run",
    }
    for artifact in set(re.findall(r"/d/hearth/\.perf/worktrees/virtio-eventfd/\.perf/eventfd/cache/local-current/o/[0-9a-f]+/test\b", text)):
        path = Path(artifact)
        assert path.exists()
        elfs.append({"path": artifact, "sha256": sha(path)})
    selected.extend(path for path in directory.iterdir()
                    if path.is_file() and path.name != "flint")
binary_hashes = {row["elf_sha256"] for row in rows.values()}
common = []
for directory in (root / ".perf/jail-baseline").iterdir():
    launch = directory / "launch.json"
    if not launch.exists() or json.loads(launch.read_text())["binary_sha256"] not in binary_hashes:
        continue
    common.append(directory)
    cleanup = json.loads((directory / "cleanup.json").read_text())
    assert not cleanup["live_pid_paths"]
    pids.update(map(int, cleanup["recorded_pids"]))
    roster = json.loads((directory / "owned-roster.json").read_text())
    for tid, value in roster.items():
        fields = dict(line.split(":", 1) for line in value.splitlines() if ":" in line)
        assert fields["Uid"].split() == ["1000"] * 4 and fields["Gid"].split() == ["1000"] * 4
        assert not fields["Groups"].strip() and fields["CapEff"].strip() == "0000000000000000"
        assert fields["NoNewPrivs"].strip() == "1" and fields["Seccomp"].strip() == "2"
        pids.add(int(tid))
    selected.extend(path for path in directory.iterdir()
                    if path.is_file() and path.suffix in (".json", ".log"))
assert len(common) == 6
failure = (private / "ReleaseSafe/instrumentation-failure.log").read_text()
failed_children = re.findall(r"enforced_case child_pid=(\d+) waited=(\d+) status=(\d+)", failure)
assert sum(status == "31" for _, _, status in failed_children) == 2
pids.update(int(pid) for pid, _, _ in failed_children)
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)
assert sha(root / ".perf/eventfd/fixtures/legacy/flint") == "bd10cfef94ef4cf2402e485913b3f4a9ffb93f9cf80d25d0310d093b55111d23"
archive_path = public / "pause-mask-validation.tar.gz"
receipt_path = public / "pause-mask-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
files = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        files.append({"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()})
    payload = json.dumps({"files": files}, indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(payload), 0o600, 0
    archive.addfile(info, io.BytesIO(payload))
with tarfile.open(archive_path, "r:gz") as archive:
    for row in files:
        assert hashlib.sha256(archive.extractfile(row["path"]).read()).hexdigest() == row["sha256"]
receipt = {
    "issue": 3, "classification": "staged native correctness and syscall-wall diagnostic, not performance qualification",
    "base_head": "7efea146094b6674ecaf783ce3c05453cdb5db6f", "rows": rows,
    "runtime_semantics_changed": False, "kernel_barriers_or_deassignment_removed": False,
    "root_call_chain": "owners.pause -> sequential Owner.pause/control -> refresh(false) -> removeKick -> KVM_IOEVENTFD DEASSIGN; IRQFD also synchronously deassigned/drained",
    "kernel_internal_rcu_or_scheduler_cause_proven": False,
    "minimal_safe_pause_optimization_adopted": False,
    "not_a_linux_workload": "three dormant vsock devices, nine ready disjoint empty rings, three GSIs; probe does not run guest instructions",
    "wall_not_cpu": "time inside ioctl includes kernel/scheduling/wait, not marginal kernel CPU",
    "failures_retained": ["initial project-mutex compile error", "two Safe SIGSYS31 from unneeded getpid logging", "3GiB guard blocked Debug before execution"],
    "failure_fix": "remove getpid logging; seccomp unchanged, no audit bypass",
    "source_capture_limit": "initial Debug compile/first-pass diff overwritten; raw logs and executed ELF remain, final source diffs captured",
    "helper_census_limit": "final native fork children and post-IRET TIDs recorded; compiler/inspection/initial Debug helper creation census incomplete",
    "recorded_owned_numbers": len(pids), "all_recorded_number_paths_absent": True,
    "executed_test_elfs_retained": elfs,
    "owned_derived_objects_cleanup": json.loads((private / "owned-derived-cleanup.json").read_text()),
    "new_candidate_samples": 0, "performance_merge_eligible": False,
    "old_linux_pause_regression_noise_halt_save_compatibility_full_congestion_gaps_unclosed": True,
    "archive": archive_path.name, "archive_sha256": sha(archive_path),
    "archive_bytes": archive_path.stat().st_size, "verified_files": len(files),
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"archive_sha256": receipt["archive_sha256"], "bytes": receipt["archive_bytes"],
                  "files": len(files), "recorded_numbers_absent": len(pids),
                  "receipt_sha256": sha(receipt_path),
                  "pause_means": {opt: {mode: {key: value for key, value in data.items() if key != "samples"}
                      for mode, data in row["pause"].items()} for opt, row in rows.items()}}))
