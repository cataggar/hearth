import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

os.umask(0o077)
root = Path.cwd()
private = root / ".perf/eventfd/q6"
out = root / "benchmarks/virtio-eventfd/results/20261004"
pids, selected, cases, cleanup = set(), [], [], []
for mode in ("L0", "C00", "C10", "C01", "C11"):
    directory = private / f"halt-{mode}"
    result = json.loads((directory / "result.json").read_text())
    assert result["status"] == "failed" and result["errors"]
    assert result["halt_snapshot_files_before_cleanup"] == {"state": None, "memory": None}
    if mode != "L0":
        assert result["actual_guest_halt_serial_marker"]
        assert result["halt_exit_timeout_seconds"] == 20 and result["initial_agent_disk"]["exec"]["exit_code"] == 0
    else:
        assert not result["actual_guest_halt_serial_marker"]
        assert "receive timed out" in result["errors"][0]
    cases.append(result)
    command = json.loads((directory / "actual-command.json").read_text())["argv"]
    assert "--save-on-halt" in command and "/state" in command and "/memory" in command
    record = json.loads((directory / "teardown.json").read_text())
    pids.update((record["supervisor_pid"], record["vmm_pid"]))
    cleanup.append({"mode": mode, **record})
    for row in json.loads((directory / "isolation.json").read_text()):
        assert row["Uid"].split() == ["1000"] * 4 and row["Gid"].split() == ["1000"] * 4
        assert not row["Groups"] and row["Seccomp"] == "2" and row["NoNewPrivs"] == "1"
        assert row["CapEff"] == "0000000000000000"
        pids.update((row["pid"], row["tid"]))
    selected.extend(path for path in directory.rglob("*") if path.is_file()
                    and not path.is_symlink() and
                    (path.suffix in (".json", ".log", ".txt") or path.name == "vmm.stderr"))
    selected.append(directory.with_suffix(".log"))
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)
selected.extend((Path(__file__), private / "save-halt.py", private / "halt-exits.log",
                 private / "seal-mixed.log", root / "benchmarks/virtio-eventfd/control.py"))
archive_path = out / "halt-acceptance-validation.tar.gz"
receipt_path = out / "halt-acceptance-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
files = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        files.append({"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()})
    payload = json.dumps({"files": files, "scope": "only owned enforced CLI halt failure/cleanup evidence; images excluded"}, indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(payload), 0o600, 0
    archive.addfile(info, io.BytesIO(payload))
with tarfile.open(archive_path, "r:gz") as archive:
    for record in files:
        assert hashlib.sha256(archive.extractfile(record["path"]).read()).hexdigest() == record["sha256"]
receipt = {
    "issue": 3, "date": "2026-10-05",
    "classification": "actual supported CLI save-on-halt acceptance failures; not inferred from API snapshots",
    "binary_sha256": "8f1ca382cc9678804cae31cecdfd4fcf7183e68986dd9249680edaae07bd8f6e",
    "actual_halt_cases": 4, "passing_halt_save_cases": 0,
    "pre_halt_legacy_transport_failure_cases": 1,
    "cases": cases, "cleanup_receipts": cleanup,
    "recorded_owned_PID_TID_numbers": len(pids), "all_recorded_owned_numbers_absent_at_seal": True,
    "diagnosis_scope": "C00 also fails; no accelerator-specific causation claimed. Kernel-handled HLT is not a userspace KVM_EXIT_HLT save event. Legacy control timed out before halt and is not counted as a halt case.",
    "remaining_qualification": ["actual CLI save-on-halt", "old/new legacy compatibility", "full active IRQ congestion/storm races",
                                 "complete marginal kernel/scheduler CPU", "fresh noise-qualified paired performance and scaling idle comparison"],
    "default_changed": False, "performance_adoption_eligible": False,
    "archive": archive_path.name, "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "archive_bytes": archive_path.stat().st_size, "verified_files": len(files),
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"archive_sha256": receipt["archive_sha256"], "bytes": receipt["archive_bytes"],
                  "files": len(files), "recorded_owned_IDs_absent": len(pids),
                  "receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest()}))
