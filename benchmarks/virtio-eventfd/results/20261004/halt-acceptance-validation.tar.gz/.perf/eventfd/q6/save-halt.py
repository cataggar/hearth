import argparse
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd() / "benchmarks/virtio-eventfd"))
import control
import run as bench

os.umask(0o077)
parser = argparse.ArgumentParser()
parser.add_argument("--mode", required=True)
args = parser.parse_args()
signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(RuntimeError("bounded halt probe interrupted")))
out = bench.artifact_path(f".perf/eventfd/q6/halt-{args.mode}")
out.mkdir(mode=0o700, parents=True, exist_ok=False)
os.sched_setaffinity(0, {1})
binary = bench.artifact_path(".perf/eventfd/q6/ReleaseSafe/flint")
result = {
    "status": "failed", "errors": [], "mode": args.mode,
    "classification": "actual CLI halt/save acceptance; current corrected L0 is not untouched historical binary",
    "binary_sha256": bench.digest(binary), "guest_agent_poll_ms": 50,
    "heartbeat_ms": 0, "performance_merge_eligible": False,
}
guest = None
original = subprocess.Popen


def launch(argv, *positional, **keywords):
    if isinstance(argv, (list, tuple)) and "--jail" in argv:
        argv = [*argv, "--save-on-halt", "--vmstate-path", "/state", "--mem-path", "/memory"]
        bench.save_json(out / "actual-command.json", {"argv": argv, "cwd": str(bench.ROOT)})
    return original(argv, *positional, **keywords)


try:
    guest = control.Guest.__new__(control.Guest)
    with patch.object(subprocess, "Popen", side_effect=launch):
        guest.__init__(out, binary, args.mode, bench.artifact_path(".perf/eventfd/fixtures/agent-hb0"),
                       disk=True, cli_only=True)
    result["initial_agent_disk"] = control.agent(guest, True)
    bench.send_message(guest.connection, {"method": "exec", "cmd": "/bin/busybox halt -f", "timeout": 5})
    try:
        result["actual_cli_exit_code"] = guest.process.wait(timeout=20)
    except subprocess.TimeoutExpired:
        result["halt_exit_timeout_seconds"] = 20
        raise RuntimeError("actual guest halt did not produce bounded CLI save/exit")
    if result["actual_cli_exit_code"] != 0:
        raise RuntimeError("CLI halted with a nonzero exit")
    state, memory = guest.path / "state", guest.path / "memory"
    if not state.exists() or not memory.exists():
        raise RuntimeError("CLI exited without requested halt snapshot files")
    result["snapshot_version"] = struct.unpack_from("<I", state.read_bytes(), 16)[0]
    if result["snapshot_version"] != 2 or memory.stat().st_size == 0:
        raise ValueError("invalid halt snapshot")
    result["status"] = "passed"
except (OSError, ValueError, RuntimeError, EOFError, subprocess.SubprocessError) as error:
    result["errors"].append(f"{type(error).__name__}: {error}")
finally:
    if guest is not None and guest.path_created:
        result["actual_guest_halt_serial_marker"] = "System halted" in (out / "serial.txt").read_text(errors="replace")
        result["halt_snapshot_files_before_cleanup"] = {
            name: (guest.path / name).stat().st_size if (guest.path / name).exists() else None
            for name in ("state", "memory")
        }
        guest.close()
    bench.save_json(out / "result.json", result)
print(json.dumps(result))
raise SystemExit(0 if result["status"] == "passed" else 1)
