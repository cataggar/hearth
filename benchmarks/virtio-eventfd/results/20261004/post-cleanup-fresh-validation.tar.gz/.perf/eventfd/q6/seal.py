import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

os.umask(0o077)
root = Path.cwd()
private = root / ".perf/eventfd/q6"
out = root / "benchmarks/virtio-eventfd/results/20261004"
gates = json.loads((private / "frozen-gates.json").read_text())
assert gates["samples"] == 5 and gates["status"] == "noise-inconclusive"
assert not gates["candidate_performance_observed"]
pids, phase_cleanup = set(), []
for path in private.rglob("teardown.json"):
    result = json.loads(path.read_text())
    assert result["supervisor_exit_code"] == 0
    pids.update((result["supervisor_pid"], result["vmm_pid"]))
    phase_cleanup.append(str(path.relative_to(root)))
for path in private.rglob("isolation.json"):
    for row in json.loads(path.read_text()):
        assert row["Uid"].split() == ["1000"] * 4 and row["Gid"].split() == ["1000"] * 4
        assert not row["Groups"] and row["Seccomp"] == "2" and row["NoNewPrivs"] == "1"
        assert row["CapEff"] == "0000000000000000"
        pids.update((row["pid"], row["tid"]))
for path in private.rglob("enforced-roster.json"):
    for row in json.loads(path.read_text()):
        pids.update((row["pid"], row["tid"]))
for path in private.glob("t-*/manifest.json"):
    pids.add(json.loads(path.read_text())["pid"])
for path in private.glob("l0-*/threads-*.json"):
    pids.update(row["tid"] for row in json.loads(path.read_text()))
for optimization in ("ReleaseSafe", "Debug"):
    assert "63/63 tests passed" in (private / f"irq-eoi-{optimization}.log").read_text()
for mode in ("C00", "C10", "C01", "C11"):
    for kind in ("n", "a", "t"):
        result = json.loads((private / f"{kind}-{mode}/result.json").read_text())
        assert result["status"] == "passed" and not result["errors"]
for count in (1, 4, 8):
    result = json.loads((private / f"c00-n{count}/result.json").read_text())
    assert result["status"] == "passed" and all(code == 0 for code in result["shutdown_exit_codes"])
assert (private / "current-controls.log").read_text().count("\nOK\n") == 2
assert len(phase_cleanup) == 26
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)
selected = []
for path in private.rglob("*"):
    if path.is_file() and not path.is_symlink() and (
        path.suffix in (".json", ".log", ".txt", ".stdout", ".stderr", ".py", ".sh")
        or path.name == "vmm.stderr"
    ):
        selected.append(path)
for name in ("run.py", "performance.py", "test_run.py", "matrix.py", "scale.py"):
    selected.append(root / "benchmarks/virtio-eventfd" / name)
selected.append(root / "vmm/src/eventfd_tests.zig")
current_pins = {
    "8f1ca382cc9678804cae31cecdfd4fcf7183e68986dd9249680edaae07bd8f6e",
    "ccd6f4fb476925efe297aac9c21f5f30d8a0172e91a0bd35a9249a9d96955c34",
}
for path in (root / ".perf/jail-tests").glob("*/launch.json"):
    launch = json.loads(path.read_text())
    if launch["binary_sha256"] in current_pins:
        pids.add(launch["supervisor_pid"])
        pids.add(json.loads((path.parent / "pid.json").read_text())["vmm_pid"])
        selected.extend(member for member in path.parent.iterdir() if member.is_file()
                        and not member.is_symlink() and
                        (member.suffix in (".json", ".log") or member.name == "process-status.txt"))
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)
archive_path = out / "post-cleanup-fresh-validation.tar.gz"
receipt_path = out / "post-cleanup-fresh-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
files = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        assert len(payload) <= 25 * 1024 * 1024
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        files.append({"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()})
    payload = json.dumps({"files": files, "scope": "only owned fresh results/source/logs; images/ELFs/raw traces excluded"}, indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(payload), 0o600, 0
    archive.addfile(info, io.BytesIO(payload))
with tarfile.open(archive_path, "r:gz") as archive:
    for record in files:
        payload = archive.extractfile(record["path"]).read()
        assert hashlib.sha256(payload).hexdigest() == record["sha256"]
receipt = {
    "issue": 3, "date": "2026-10-05", "classification": "fresh post-cleanup validation; not an optimization comparison",
    "source_base": "5a71144903bb421700b788a492248ed1d135de31",
    "fresh_AA": {"blocks": 5, "cells": 85, "binary_sha256": gates["binary_sha256"],
                 "status": gates["status"], "noise_failed_classes": gates["exceeds_noise_caps"],
                 "primary": gates["noise"]["disk-flush-4096"],
                 "gates_sha256": hashlib.sha256((private / "frozen-gates.json").read_bytes()).hexdigest(),
                 "new_candidate_performance_samples": 0},
    "collector_tests": 18, "target": "x86_64-linux-musl",
    "current_tests_per_optimization": {"units": 39, "dedicated": 17, "real_dedicated_KVM": 16,
                                     "existing_integrations": 7, "real_existing_guest_integrations": 5,
                                     "total_passed": 63, "skips": 0},
    "new_IOAPIC_EOI_first_scenarios_per_optimization": 4,
    "new_IOAPIC_full_active_congestion_storm_coverage_claimed": False,
    "fresh_current_jail_cases_per_optimization": 4, "fresh_current_no_heartbeat_Linux_cases": 12,
    "current_ELFs": {"ReleaseSafe": "8f1ca382cc9678804cae31cecdfd4fcf7183e68986dd9249680edaae07bd8f6e",
                     "Debug": "ccd6f4fb476925efe297aac9c21f5f30d8a0172e91a0bd35a9249a9d96955c34"},
    "fresh_C00_native_scale_counts": [1, 4, 8],
    "mixed_device_four_eight_VM_qualification_claimed": False,
    "owned_VM_phase_cleanup_receipts": phase_cleanup,
    "recorded_owned_PID_TID_numbers": len(pids), "all_recorded_owned_numbers_absent_at_seal": True,
    "helper_cleanup": "perf collectors waited return0; kernel observers completed STOP/closed unpinned maps+fds; own VM supervisor receipts; helper PID creation census not captured in this batch",
    "parent_residual_load": "externally reported8.733/16; no unrelated tasks inspected/terminated/moved",
    "old_saturation_and_noisy_data_used_for_current_qualification": False,
    "pre_post_cleanup_claimed_as_optimization": False, "numeric_policy_caps_relaxed": False,
    "default_changed": False, "performance_adoption_eligible": False,
    "archive": archive_path.name, "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "archive_bytes": archive_path.stat().st_size, "verified_files": len(files),
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"archive_sha256": receipt["archive_sha256"], "bytes": receipt["archive_bytes"],
                  "files": len(files), "recorded_owned_IDs_absent": len(pids),
                  "receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest()}))
