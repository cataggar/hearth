set -eu
umask 077
export TMPDIR="$PWD/.perf/eventfd/cache" PYTHONDONTWRITEBYTECODE=1
for optimization in ReleaseSafe Debug; do
    timeout 90 env FLINT_JAIL_TEST_BINARY="$PWD/.perf/eventfd/q6/$optimization/flint" \
        python3 -m unittest discover -s tools/perf -p test_jail_prerequisites.py -v
done
for mode in C00 C10 C01 C11; do
    timeout 60 python3 benchmarks/virtio-eventfd/control.py \
        --out ".perf/eventfd/q6/n-$mode" --binary .perf/eventfd/q6/ReleaseSafe/flint \
        --mode "$mode" --fixture .perf/eventfd/fixtures/native-hb0
    timeout 60 python3 benchmarks/virtio-eventfd/control.py \
        --out ".perf/eventfd/q6/a-$mode" --binary .perf/eventfd/q6/ReleaseSafe/flint \
        --mode "$mode" --fixture .perf/eventfd/fixtures/agent-hb0 --disk --disconnect-pending
    timeout 60 sudo -n unshare --net python3 benchmarks/virtio-eventfd/tap_probe.py \
        --out ".perf/eventfd/q6/t-$mode" --binary .perf/eventfd/q6/ReleaseSafe/flint \
        --virtio-mode "$mode" --fixture .perf/eventfd/fixtures/tap-no-heartbeat --label IOAPIC-EOI-first-control
done
sha256sum .perf/eventfd/q6/ReleaseSafe/flint .perf/eventfd/q6/Debug/flint
