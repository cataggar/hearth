set -eu
umask 077
cd /d/hearth/.perf/worktrees/virtio-eventfd
export TMPDIR="$PWD/.perf/eventfd/cache" PYTHONDONTWRITEBYTECODE=1
for index in 01 02 03 04 05; do
    timeout 1200 flock -x -w 800 /d/hearth/.perf/fleet/host.lock \
        timeout 360 sudo -n unshare --net python3 benchmarks/virtio-eventfd/performance.py \
        --out ".perf/eventfd/q6/aa-$index" --binary .perf/eventfd/w5/ioapic/ReleaseSafe/flint \
        --fixture .perf/eventfd/fixtures/all-device-perf --mode C00 --minimum-seconds 5 \
        > ".perf/eventfd/q6/aa-$index.phase.log" 2>&1
done
timeout 900 flock -x -w 800 /d/hearth/.perf/fleet/host.lock timeout 60 \
    python3 benchmarks/virtio-eventfd/performance.py --freeze \
    --baselines .perf/eventfd/q6 --out .perf/eventfd/q6/frozen-gates.json \
    --binary .perf/eventfd/w5/ioapic/ReleaseSafe/flint \
    --fixture .perf/eventfd/fixtures/all-device-perf \
    > .perf/eventfd/q6/freeze.log 2>&1
