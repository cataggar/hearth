#!/usr/bin/env python3
"""Seal only explicitly selected, completed owned correctness evidence."""

import hashlib
import io
import json
import os
from pathlib import Path
import re
import tarfile
import time

os.umask(0o077)
ROOT = Path.cwd()
PRIVATE = ROOT / ".perf/eventfd/w5"
OUT = ROOT / "benchmarks/virtio-eventfd/results/20261004"
PINS = {
    "ReleaseSafe": "4c3bd1bd56cd4c58aa1c581658a473e640a0e759c41057459dd1dd1fd3fad5de",
    "Debug": "5b9f7201168d1b0b614d3d31d69da6813385c006aeb800999c989146f60dc84d",
}
selected = [Path(__file__).resolve()]
logs = {
    "safe": PRIVATE / "shared-filter/resume-safe.log",
    "debug": PRIVATE / "shared-filter/resume-debug.log",
    "controls": PRIVATE / "shared-filter/resume-safe-controls.log",
    "debug_jail": PRIVATE / "shared-filter/resume-debug-jail-final.log",
}
selected.extend(logs.values())
assert "53/53 tests passed" in logs["safe"].read_text()
assert "60/60 tests passed" in logs["debug"].read_text()
assert "7/7 tests passed" in logs["controls"].read_text()
assert re.search(r"Ran 4 tests in [^\n]+\n\nOK", logs["controls"].read_text())
assert re.search(r"Ran 17 tests in [^\n]+\n\nOK", logs["controls"].read_text())
assert re.search(r"Ran 4 tests in [^\n]+\n\nOK", logs["debug_jail"].read_text())
for optimization, expected in PINS.items():
    binary = PRIVATE / f"shared-filter/{optimization}/flint"
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected

guest_results = []
pids = set()
for mode in ("C00", "C10", "C01", "C11"):
    for kind in ("n", "a", "t"):
        directory = PRIVATE / f"sf-{kind}-{mode}"
        result = json.loads((directory / "result.json").read_text())
        assert result["status"] == "passed" and result["errors"] == []
        manifest = json.loads((directory / "manifest.json").read_text())
        assert manifest["binary_sha256"] == PINS["ReleaseSafe"]
        roster_path = directory / ("enforced-roster.json" if kind == "t" else "isolation.json")
        roster = json.loads(roster_path.read_text())
        for row in roster:
            assert row["Uid"].split() == [str(os.getuid())] * 4
            assert row["Gid"].split() == [str(os.getgid())] * 4
            assert not row["Groups"].strip()
            assert row["CapEff"] == "0000000000000000"
            assert row["Seccomp"] == "2" and row["NoNewPrivs"] == "1"
            pids.update((int(row["pid"]), int(row["tid"])))
        if kind == "t":
            assert manifest["heartbeat_ms"] == 0
            pids.add(manifest["pid"])
            client = json.loads((directory / "client-result.json").read_text())
            assert client["status"] == "passed"
            assert len(client["responses"]) == 4
            assert all(phase["status"] == "passed" for phase in client["phases"])
            details = {
                "checked_messages": 18,
                "post_silence_seconds": 2,
                "controlled_termination_signal": "SIGTERM",
                "graceful_shutdown_claimed": False,
                "operation_window_seconds": result["operation_window_seconds"],
                "host_noise_control": result["host_noise_control"],
            }
        else:
            assert manifest["heartbeat_ms"] == 0
            assert result["shutdown_exit_code"] == 0
            teardown = json.loads((directory / "teardown.json").read_text())
            pids.update((teardown["vmm_pid"], teardown["supervisor_pid"]))
            details = {"shutdown_exit_code": 0}
            if kind == "n":
                assert len(result["native"]["messages"]) == 8
                details["checked_messages"] = 8
                details["bytes_each_direction"] = result["native"]["bytes_each_direction"]
            else:
                assert result["disconnect_pending"]["guest_reconnected"]
                assert result["host_disk_marker"] == "EVENTFD"
                assert result["agent"]["agent_poll_ms"] == 50
                details["unchanged_agent_poll_ms"] = 50
                details["pending_write_reconnect"] = True
                details["host_disk_marker"] = "EVENTFD"
        guest_results.append({
            "mode": mode, "kind": kind, "status": "passed",
            "owned_task_count": len(roster), **details,
        })
        for path in directory.iterdir():
            if path.is_file() and not path.is_symlink() and (
                path.suffix == ".json" or path.name in {
                    "vmm.stderr", "serial.txt", "guest-serial.txt",
                    "client.stdout", "client.stderr", "source-diff.txt",
                }
            ):
                selected.append(path)

jail_launches = []
for launch_path in (ROOT / ".perf/jail-tests").glob("*/launch.json"):
    launch = json.loads(launch_path.read_text())
    if launch["binary_sha256"] not in PINS.values():
        continue
    directory = launch_path.parent
    pids.add(launch["supervisor_pid"])
    pids.add(json.loads((directory / "pid.json").read_text())["vmm_pid"])
    exit_record = json.loads((directory / "exit.json").read_text())
    pids.update((exit_record["vmm_pid"], exit_record["supervisor_pid"]))
    seeded = "--groups=0" in launch["argv"]
    if seeded:
        status = dict(line.split(":", 1) for line in (directory / "process-status.txt").read_text().splitlines() if ":" in line)
        assert not status["Groups"].strip()
        assert status["CapEff"].strip() == "0000000000000000"
        assert status["Seccomp"].strip() == "2"
        assert status["NoNewPrivs"].strip() == "1"
    jail_launches.append({
        "binary_sha256": launch["binary_sha256"],
        "seeded_root_group": seeded,
        "path": str(directory.relative_to(ROOT)),
    })
    for path in directory.iterdir():
        if path.is_file() and not path.is_symlink() and (
            path.suffix == ".json" or path.name in {"stdout.log", "stderr.log", "process-status.txt"}
        ):
            selected.append(path)
for expected in PINS.values():
    assert any(item["binary_sha256"] == expected and item["seeded_root_group"] for item in jail_launches)
assert all(not Path(f"/proc/{pid}").exists() for pid in pids if pid is not None)

host_control_path = PRIVATE / "shared-filter/no-owned-vm-host-control.json"
assert not host_control_path.exists()
before = Path("/proc/stat").read_text().splitlines()[0]
started = time.monotonic()
time.sleep(5)
seconds = time.monotonic() - started
after = Path("/proc/stat").read_text().splitlines()[0]
assert all(not Path(f"/proc/{pid}").exists() for pid in pids if pid is not None)
ticks = os.sysconf("SC_CLK_TCK")
delta = [int(new) - int(old) for old, new in zip(before.split()[1:9], after.split()[1:9])]
busy = sum(delta[index] for index in (0, 1, 2, 5, 6)) / ticks
host_control = {
    "scope": "independent aggregate no-owned-VM host floor; not backend CPU or A/A",
    "before_first_eight_cpu_fields": before,
    "after_first_eight_cpu_fields": after,
    "seconds": seconds, "clock_ticks_per_second": ticks,
    "busy_definition": "user+nice+system+irq+softirq; guest not added again",
    "busy_cpu_seconds": busy, "busy_cores": busy / seconds,
    "iowait_cpu_seconds": delta[4] / ticks, "steal_cpu_seconds": delta[7] / ticks,
}
host_control_path.write_text(json.dumps(host_control, indent=2) + "\n")
selected.append(host_control_path)

archive_path = OUT / "shared-filter-validation.tar.gz"
receipt_path = OUT / "shared-filter-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
records = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        assert len(payload) <= 20 * 1024 * 1024
        name = str(path.relative_to(ROOT))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        records.append({"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()})
    manifest = json.dumps({
        "schema": 1, "files": records,
        "classification": "fresh shared-filter correctness only; not performance qualification",
        "excluded": ["VM memory/disk/state, binaries/initrds, unrelated task metadata, raw traces"],
    }, indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(manifest), 0o600, 0
    archive.addfile(info, io.BytesIO(manifest))
with tarfile.open(archive_path, "r:gz") as archive:
    for record in records:
        payload = archive.extractfile(record["path"]).read()
        assert len(payload) == record["bytes"]
        assert hashlib.sha256(payload).hexdigest() == record["sha256"]
receipt = {
    "issue": 3, "kind": "shared_filter_and_inherited_group_correctness_followup",
    "date": "2026-10-05", "runtime_build_source_commit": "b8a9b3760dccab303252d7d4949b110abef00fd7",
    "shared_chain": [
        "f2f9ab4c8e7a67097f2c3f52636327e9c41d5084",
        "5ee81b163b266f9c7643fb67c88cb59fe7aa2878",
        "ced7ed72b5b2f80286e37ba8c9d5eada0cb90236",
    ],
    "binary_sha256": PINS,
    "zig_target": "x86_64-linux-musl",
    "exclusive_lock": "/d/hearth/.perf/fleet/host.lock", "umask": "077",
    "unit_tests_per_optimization": 39,
    "dedicated_tests_per_optimization": {"total": 14, "real_enforced_kvm": 13, "policy_unit": 1},
    "existing_integration_per_optimization": {"total": 7, "real_guest": 5, "cli_errors": 2, "heartbeat": True},
    "unit_enforced_fork_case": {"successful_filtered_thread_and_readiness_case": 1, "actual_SIGSYS_denials": 11, "new_narrowing_denials": 4},
    "python_jail_per_optimization": {"total": 4, "actual_enforced_API": 2, "deterministic_PID_cleanup": 2, "deliberate_inherited_root_group_case": 1},
    "benchmark_python_tests": 17, "skips": 0,
    "fresh_no_heartbeat_linux_cases": guest_results,
    "jail_launches": jail_launches,
    "recorded_owned_pid_or_tid_count": len(pids),
    "all_recorded_owned_pids_absent_at_seal": True,
    "archive": archive_path.name,
    "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "archive_bytes": archive_path.stat().st_size,
    "archive_verified_files": len(records),
    "logs": {name: {"path": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in logs.items()},
    "subsequent_Debug_jail_lock_refusals": [
        {"request": "eventfd-resume-debug-jail", "wait_seconds": 480, "exit_code": 1, "tests_executed": 0},
        {"request": "eventfd-resume-seal", "wait_seconds": 1200, "exit_code": 1, "tests_executed": 0},
        {"request": "eventfd-resume-seal-2", "wait_seconds": 300, "exit_code": 1, "tests_executed": 0},
    ],
    "new_IOAPIC_tests_included_in_these_binary_validation_counts": False,
    "prior_acquired_attempt_failed_before_test": {
        "request": "eventfd-ioapic-abi-probe",
        "reason": "ENOSPC opening redirected Debug jail log",
        "tests_executed": 0,
        "IOAPIC_probes_executed": 0,
    },
    "historical_pending_receipt_superseded_not_overwritten": "shared-filter-pending.json",
    "historical_build19_pins_changed": False,
    "performance_samples_collected": 0, "frozen_gates_changed": False,
    "default_changed": False, "performance_adoption_eligible": False,
    "current_TAP_host_control_is_independent_idle_or_AA": False,
    "new_independent_no_owned_VM_host_floor": host_control,
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({
    "archive_sha256": receipt["archive_sha256"],
    "archive_bytes": receipt["archive_bytes"],
    "verified_files": len(records),
    "owned_pids_absent": len(pids),
    "receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
}))
