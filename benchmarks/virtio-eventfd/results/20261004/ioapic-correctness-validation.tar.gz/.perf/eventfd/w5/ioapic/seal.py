import hashlib
import io
import json
import os
from pathlib import Path
import re
import tarfile

os.umask(0o077)
root = Path.cwd()
private = root / ".perf/eventfd/w5/ioapic"
out = root / "benchmarks/virtio-eventfd/results/20261004"
pins = {
    "ReleaseSafe": "d0beacfc752f7fd2917d26c829447252490707a4c578c8f85e340f5bae2f4ea0",
    "Debug": "18b3a12bd3f57a2ea616bb4d7106d48acca013a90a7d319f07f79f8575a6c9a4",
}
logs = [
    private / name for name in (
        "baseline-safe.log", "baseline-safe-abi-final.log",
        "fixed-safe.log", "fixed-debug.log", "fixed-linux-controls-final.log",
    )
]
assert "15/16 tests passed (1 failed)" in logs[1].read_text()
assert "array of opaque type" in logs[0].read_text()
for path in logs[2:4]:
    assert "55/55 tests passed" in path.read_text()
assert len(re.findall(r"Ran 4 tests in [^\n]+\n\nOK", logs[4].read_text())) == 2
assert len(re.findall(r"^FIXED_(?:native|agent|tap)_C[01]{2}_PASS$", logs[4].read_text(), re.M)) == 12
for optimization, expected in pins.items():
    assert hashlib.sha256((private / optimization / "flint").read_bytes()).hexdigest() == expected

selected = [*logs, Path(__file__).resolve(), private / "fixed-controls.sh"]
sources = [
    root / path for path in (
        "vmm/src/devices/virtio/accelerator.zig",
        "vmm/src/devices/virtio/owner.zig", "vmm/src/eventfd_tests.zig",
        "vmm/src/kvm/abi.h", "vmm/src/seccomp.zig",
        "tools/perf/test_jail_prerequisites.py",
    )
]
selected.extend(sources)
cases, pids = [], set()
for mode in ("C00", "C10", "C01", "C11"):
    for kind in ("n", "a", "t"):
        directory = root / f".perf/eventfd/w5/i-{kind}-{mode}"
        result = json.loads((directory / "result.json").read_text())
        manifest = json.loads((directory / "manifest.json").read_text())
        assert result["status"] == "passed" and not result["errors"]
        assert manifest["binary_sha256"] == pins["ReleaseSafe"]
        roster = json.loads((directory / ("enforced-roster.json" if kind == "t" else "isolation.json")).read_text())
        for row in roster:
            assert row["Uid"].split() == [str(os.getuid())] * 4
            assert row["Gid"].split() == [str(os.getgid())] * 4
            assert not row["Groups"].strip() and row["CapEff"] == "0000000000000000"
            assert row["Seccomp"] == "2" and row["NoNewPrivs"] == "1"
            pids.update((row["pid"], row["tid"]))
        if kind == "t":
            assert manifest["heartbeat_ms"] == 0
            pids.add(manifest["pid"])
            client = json.loads((directory / "client-result.json").read_text())
            assert client["status"] == "passed" and all(p["status"] == "passed" for p in client["phases"])
            assert len(client["responses"]) == 4
            detail = {"checked_messages": 18, "post_silence_seconds": 2,
                      "owned_VMM_terminated_with_SIGTERM_not_graceful_exit": True}
        else:
            assert manifest["heartbeat_ms"] == 0 and result["shutdown_exit_code"] == 0
            cleanup = json.loads((directory / "teardown.json").read_text())
            pids.update((cleanup["supervisor_pid"], cleanup["vmm_pid"]))
            detail = {"graceful_exit_code": 0}
            if kind == "n":
                assert len(result["native"]["messages"]) == 8
                detail["checked_messages"] = 8
                detail["bytes_each_direction"] = 524288
            else:
                assert result["disconnect_pending"]["guest_reconnected"]
                assert result["host_disk_marker"] == "EVENTFD"
                detail["pending_write_reconnect"] = True
                detail["unchanged_agent_poll_ms"] = 50
        cases.append({"mode": mode, "kind": kind, "status": "passed",
                      "all_actual_tasks_enforced_nonroot_empty_groups_cap0": True, **detail})
        for path in directory.iterdir():
            if path.is_file() and not path.is_symlink() and (
                path.suffix == ".json" or path.name in {
                    "vmm.stderr", "serial.txt", "guest-serial.txt",
                    "client.stdout", "client.stderr", "source-diff.txt",
                }
            ):
                selected.append(path)
seeded = set()
for path in (root / ".perf/jail-tests").glob("*/launch.json"):
    launch = json.loads(path.read_text())
    if launch["binary_sha256"] not in pins.values():
        continue
    directory = path.parent
    pids.add(launch["supervisor_pid"])
    pids.add(json.loads((directory / "pid.json").read_text())["vmm_pid"])
    if "--groups=0" in launch["argv"]:
        seeded.add(launch["binary_sha256"])
        fields = dict(line.split(":", 1) for line in (directory / "process-status.txt").read_text().splitlines() if ":" in line)
        assert not fields["Groups"].strip()
    for member in directory.iterdir():
        if member.is_file() and not member.is_symlink() and (
            member.suffix == ".json" or member.name in {"stdout.log", "stderr.log", "process-status.txt"}
        ):
            selected.append(member)
assert seeded == set(pins.values())
assert all(not Path(f"/proc/{pid}").exists() for pid in pids)

archive_path = out / "ioapic-correctness-validation.tar.gz"
receipt_path = out / "ioapic-correctness-validation.json"
assert not archive_path.exists() and not receipt_path.exists()
records = []
with tarfile.open(archive_path, "w:gz", compresslevel=6) as archive:
    for path in sorted(set(selected)):
        payload = path.read_bytes()
        assert len(payload) <= 20 * 1024 * 1024
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(payload), 0o600, 0
        archive.addfile(info, io.BytesIO(payload))
        records.append({"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()})
    manifest = json.dumps({"files": records, "classification": "owned correctness only",
                           "excluded": ["VM memory/disk/state, executable fixtures, raw traces, unrelated task metadata"]},
                          indent=2).encode()
    info = tarfile.TarInfo("EVIDENCE-MANIFEST.json")
    info.size, info.mode, info.mtime = len(manifest), 0o600, 0
    archive.addfile(info, io.BytesIO(manifest))
with tarfile.open(archive_path, "r:gz") as archive:
    for record in records:
        payload = archive.extractfile(record["path"]).read()
        assert len(payload) == record["bytes"]
        assert hashlib.sha256(payload).hexdigest() == record["sha256"]
receipt = {
    "issue": 3, "date": "2026-10-05", "kind": "common_masked_IOAPIC_correctness_not_performance",
    "binary_sha256": pins, "target": "x86_64-linux-musl",
    "source_base_commit": "b8a9b3760dccab303252d7d4949b110abef00fd7",
    "source_tree_at_execution": "base plus archived narrow masked-route correction, IOAPIC tests/C-offset and seeded-group test",
    "source_sha256": {
        str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sources
    },
    "exclusive_lock": "/d/hearth/.perf/fleet/host.lock", "umask": "077",
    "before": {"unchanged_policy_dedicated_passed": 15, "total": 16,
               "failed_real_case": "masked level IOAPIC with edge PIC also masked; first case ordinary IRQ_LINE",
               "prior_compile_error_is_not_KVM_test_execution": True},
    "after_per_optimization": {
        "unit_tests": 39, "dedicated_tests": 16, "dedicated_real_enforced_KVM": 15,
        "dedicated_policy_unit": 1, "combined_passed": 55, "skips": 0,
        "new_unmasked_IOAPIC_edge_level_line_IRQFD_scenarios": 4,
        "new_masked_IOAPIC_level_unmask_reset_line_IRQFD_scenarios": 4,
        "standalone_Python_jail_cases": 4, "deliberately_seeded_root_group_cases": 1,
    },
    "post_correction_no_heartbeat_Linux_cases": cases,
    "recorded_owned_PID_TID_count": len(pids), "all_recorded_owned_IDs_absent_at_seal": True,
    "existing_seven_integration_cases_reexecuted_after_this_correction": False,
    "existing_b8a9_integration_and_performance_pins_relabelled": False,
    "archive": archive_path.name, "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "archive_bytes": archive_path.stat().st_size, "archive_verified_files": len(records),
    "frozen_gates_changed": False, "performance_samples_collected": 0,
    "default_changed": False, "performance_adoption_eligible": False,
    "remaining": [
        "qualified quiet full paired performance matrix and confidence",
        "complete marginal kernel dispatcher/scheduler CPU",
        "mixed-device four/eight-VM qualification",
        "active IOAPIC congestion and full EOI-before-ACK lifecycle coverage",
        "old-new legacy compatibility, actual save-on-halt, host-glibc setup",
    ],
}
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"archive_sha256": receipt["archive_sha256"], "bytes": receipt["archive_bytes"],
                  "verified_files": len(records), "owned_IDs_absent": len(pids),
                  "receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest()}))
