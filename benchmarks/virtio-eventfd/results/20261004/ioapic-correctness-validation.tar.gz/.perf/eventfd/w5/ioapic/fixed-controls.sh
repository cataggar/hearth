set -eu
umask 077
export TMPDIR="$PWD/.perf/eventfd/cache" PYTHONDONTWRITEBYTECODE=1
date -u +%FT%TZ
failed=0
for optimization in ReleaseSafe Debug; do
    printf 'FIXED_JAIL_%s\n' "$optimization"
    if timeout 90 env FLINT_JAIL_TEST_BINARY="$PWD/.perf/eventfd/w5/ioapic/$optimization/flint" \
        python3 -m unittest discover -s tools/perf -p test_jail_prerequisites.py -v; then
        printf 'FIXED_JAIL_%s_PASS\n' "$optimization"
    else
        failed=1
    fi
done
for mode in C00 C10 C01 C11; do
    for kind in native agent tap; do
        printf 'FIXED_%s_%s\n' "$kind" "$mode"
        status=0
        case "$kind" in
            native)
                timeout 60 python3 benchmarks/virtio-eventfd/control.py \
                    --out ".perf/eventfd/w5/i-n-$mode" --binary .perf/eventfd/w5/ioapic/ReleaseSafe/flint \
                    --mode "$mode" --fixture .perf/eventfd/fixtures/native-hb0 || status=$?
                ;;
            agent)
                timeout 60 python3 benchmarks/virtio-eventfd/control.py \
                    --out ".perf/eventfd/w5/i-a-$mode" --binary .perf/eventfd/w5/ioapic/ReleaseSafe/flint \
                    --mode "$mode" --fixture .perf/eventfd/fixtures/agent-hb0 --disk --disconnect-pending || status=$?
                ;;
            tap)
                timeout 60 sudo -n unshare --net python3 benchmarks/virtio-eventfd/tap_probe.py \
                    --out ".perf/eventfd/w5/i-t-$mode" --binary .perf/eventfd/w5/ioapic/ReleaseSafe/flint \
                    --virtio-mode "$mode" --fixture .perf/eventfd/fixtures/tap-no-heartbeat \
                    --label masked-route-correctness || status=$?
                ;;
        esac
        if test "$status" -eq 0; then
            printf 'FIXED_%s_%s_PASS\n' "$kind" "$mode"
        else
            failed=1
        fi
    done
done
sha256sum .perf/eventfd/w5/ioapic/ReleaseSafe/flint .perf/eventfd/w5/ioapic/Debug/flint
date -u +%FT%TZ
exit "$failed"
